
# Jarviso

This is the prototype for the Jarviso assistant. 

## Setup

1. Install the necessary libraries.
2. Set up your OpenAI API key in the `config/api_keys.json` file.
3. Run `main.py` to start interacting with Jarviso.

## Development

Jarviso is in its early stages. The project is modular, allowing for easy expansions and improvements. Ensure you replace placeholders, especially API keys, and expand on the provided functionalities.
