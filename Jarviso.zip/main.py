from src.jarviso import interact_with_user

if __name__ == "__main__":
    print("Welcome to Jarviso! Start your interaction by typing a message.")
    print("Type 'exit' or 'quit' to end the session.\n")
    interact_with_user()
