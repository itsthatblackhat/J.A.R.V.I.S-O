import sqlite3
import numpy as np
from typing import List

DATABASE_NAME = 'jarviso.db'  # The SQLite database name


def generate_embeddings(text: str) -> List[float]:
    """
    Generate embeddings for the provided text.
    Note: This is a dummy function and should be replaced with a real embedding generation mechanism.

    Args:
    - text: The text for which embeddings are to be generated.

    Returns:
    - embeddings: A list of floats representing the embeddings.
    """

    # For simplicity, we'll return a dummy embedding based on the length of the text
    # Replace this with your actual embedding logic
    return [len(text) * 0.1] * 300


def store_embedding_in_db(text: str, embedding: List[float]):
    """
    Store embeddings in the SQLite database.

    Args:
    - text: The original text for which the embedding was generated.
    - embedding: The embedding to store.
    """

    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()

    # Convert embedding to a string format for storage
    embedding_str = ','.join(map(str, embedding))

    cursor.execute('INSERT INTO embeddings (text, embedding) VALUES (?, ?)', (text, embedding_str))
    conn.commit()
    conn.close()


def retrieve_embedding_from_db(text: str) -> List[float]:
    """
    Retrieve embeddings from the SQLite database based on text.

    Args:
    - text: The text for which the embedding is required.

    Returns:
    - embedding: The retrieved embedding as a list of floats.
    """

    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()

    cursor.execute('SELECT embedding FROM embeddings WHERE text = ?', (text,))
    embedding_str = cursor.fetchone()

    conn.close()

    if embedding_str:
        return list(map(float, embedding_str[0].split(',')))
    else:
        return []


# Example usage:
text_sample = "Hello Jarviso"
embedding_sample = generate_embeddings(text_sample)
store_embedding_in_db(text_sample, embedding_sample)
retrieved_embedding = retrieve_embedding_from_db(text_sample)
print(retrieved_embedding)
