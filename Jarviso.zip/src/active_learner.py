import random

class ActiveLearner:
    def __init__(self):
        self.unlabeled_data = []  # This could be a list of queries that the model is uncertain about

    def add_unlabeled_data(self, data):
        """Add data that the model might want to query the user about in the future."""
        self.unlabeled_data.append(data)

    def get_data_for_labeling(self):
        """
        Get a random piece of data for labeling.

        Returns:
        - tuple or None: An uncertain interaction to be labeled or None if no data is available.
        """
        if not self.unlabeled_data:  # Check if the list is empty
            return None
        return random.choice(self.unlabeled_data)

    def receive_label(self, data, label):
        """Receive a label for a specific data point."""
        # Here, you would add the data and label to your training set and retrain your model.
        # For simplicity, we'll just remove the data point from the unlabeled set.
        self.unlabeled_data.remove(data)
        # In a real-world scenario, you would add this data-label pair to your training set and perhaps periodically retrain your model.
